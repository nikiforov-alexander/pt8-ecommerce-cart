  
 insert into product (product_id, name, desc, thumb_image_name, full_image_name, price, quantity) values (1, 'Corkscrew', 'A screw for corks', 'corkscrew.jpg', 'corkscrew.jpg', 189.79, 5);
 insert into product (product_id, name, desc, thumb_image_name, full_image_name, price, quantity) values (2, 'Fork', 'A truly magnificent fork', 'fork.jpg', 'fork.jpg', 1819.79, 5);
 insert into product (product_id, name, desc, thumb_image_name, full_image_name, price, quantity) values (3, 'Frog', 'Not a toad. Do you even know the difference?', 'frog.jpg', 'frog.jpg', 134.79, 5);
 insert into product (product_id, name, desc, thumb_image_name, full_image_name, price, quantity) values (4, 'Glasses', 'More than one glass', 'glasses.jpg', 'glasses.jpg', 129.79, 5);
 insert into product (product_id, name, desc, thumb_image_name, full_image_name, price, quantity) values (5, 'Lens', 'Suitable for focusing light. Available as either convex or concave', 'lens.jpg', 'lens.jpg', 199.79, 5);
 insert into product (product_id, name, desc, thumb_image_name, full_image_name, price, quantity) values (6, 'Scissor', 'Please do not run with these', 'scissor.jpg', 'scissor.jpg', 119.79, 5);
 insert into product (product_id, name, desc, thumb_image_name, full_image_name, price, quantity) values (7, 'Shaving', 'More than trimming', 'shaving.jpg', 'shaving.jpg', 89.79, 5);
